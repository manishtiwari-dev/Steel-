<link href="{{ asset('backend/assets/css/main.css') }}" rel="stylesheet" type="text/css" />
<link href="{{ asset('backend/custom/custom.css') }}" rel="stylesheet" type="text/css" />
<!-- 3rd party -->
<link rel="stylesheet" href="{{ asset('backend/common/css/toastr.css') }}">
<!-- 3rd party -->

{{-- <link rel="stylesheet" href="{{ asset('backend/default/assets/css/main-rtl.css') }}"> --}}


<link rel="stylesheet" href="{{ asset('backend/common/css/select2.css') }}">
{{-- <link rel="stylesheet" href="{{ asset('backend/common/css/custom.css') }}"> --}}

