<x-frontend.app-layout>

    @section('title')
        {{ localize('Gallery') }} {{ getSetting('title_separator') }} {{ getSetting('system_title') }}
    @endsection
    <!-- ==============banner================ -->
    <!-- <section class="page-banner position-relative"
        style="background: url({{ asset('frontend/assets/img/Industries_hero.webp') }})no-repeat;    min-height: 390px;
      background-repeat: no-repeat;background-position: center center;display: flex;">
        <div class="container justify-content-center d-flex">
            <div class="row align-items-center">
                <h1 class="text-white">Gallery</h1>
            </div>
        </div>

    </section> -->
    
    <section class="black-bg">
        
        </section>
        <div class="container mt-5 gallery-wrapper">
            <div class="row text-center mx-auto">
                <div class="sec-title ">
                    <h2 class="mb-0 pb-3">Bulk Manufacturing </h2>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-3  col-md-6 ">
                    <div class="gallery-item">
                     <img class="gallery-img img-fluid" src="{{ asset('frontend/assets/img/gallery/Bulk_manufacturing.webp') }}" alt="Bulk Manufacturing"/> 
                    </div>
                 </div>
                 <div class="col-lg-3  col-md-6">
                    <div class="gallery-item">
                     <img class="gallery-img img-fluid" src="{{ asset('frontend/assets/img/gallery/Bulk_manufacturing_(1).webp') }}" alt="Bulk Manufacturing"/> 
                    </div>
                 </div>
                 <div class="col-lg-3  col-md-6">
                    <div class="gallery-item">
                      <img class="gallery-img img-fluid" src="{{ asset('frontend/assets/img/gallery/Bulk_Manufacturing_(2).webp') }}" alt="Bulk Manufacturing"/> 
                    </div>
                 </div>
                 <div class="col-lg-3  col-md-6">
                      <div class="gallery-item"> 
                        <img class="gallery-img img-fluid" src="{{ asset('frontend/assets/img/gallery/Bulk_Manufacturing_(3).webp') }}" alt="Bulk Manufacturing"/> 
                     </div>
                 </div>
                 <div class="col-lg-3  col-md-6">
                      <div class="gallery-item"> 
                        <img class="gallery-img img-fluid" src="{{ asset('frontend/assets/img/gallery/Bulk_Manufacturing_(4).webp') }}" alt="Bulk Manufacturing"/> 
                     </div>
                 </div>
                 <div class="col-lg-3  col-md-6">
                      <div class="gallery-item"> 
                        <img class="gallery-img img-fluid" src="{{ asset('frontend/assets/img/gallery/Bulk_Manufacturing_(5).webp') }}" alt="Bulk Manufacturing"/> 
                     </div>
                 </div>
                 <div class="col-lg-3  col-md-6">
                      <div class="gallery-item"> 
                        <img class="gallery-img img-fluid" src="{{ asset('frontend/assets/img/gallery/Bulk_Manufacturing_(6).webp') }}" alt="Bulk Manufacturing"/> 
                     </div>
                 </div>
                 <div class="col-lg-3  col-md-6">
                      <div class="gallery-item"> 
                        <img class="gallery-img img-fluid" src="{{ asset('frontend/assets/img/gallery/Bulk_Manufacturing_(7).webp') }}" alt="Bulk Manufacturing"/> 
                     </div>
                 </div>
                 <div class="col-lg-3  col-md-6">
                      <div class="gallery-item"> 
                        <img class="gallery-img img-fluid" src="{{ asset('frontend/assets/img/gallery/Bulk_Manufacturing_(8).webp') }}" alt="Bulk Manufacturing"/> 
                     </div>
                 </div>
                 <div class="col-lg-3  col-md-6">
                      <div class="gallery-item"> 
                        <img class="gallery-img img-fluid" src="{{ asset('frontend/assets/img/gallery/Bulk_Manufacturing_(9).webp') }}" alt="Bulk Manufacturing"/> 
                     </div>
                 </div>
                 <div class="col-lg-3  col-md-6">
                      <div class="gallery-item"> 
                        <img class="gallery-img img-fluid" src="{{ asset('frontend/assets/img/gallery/Bulk_Manufacturing_(10).webp') }}" alt="Bulk Manufacturing"/> 
                     </div>
                 </div>
                 <div class="col-lg-3  col-md-6">
                      <div class="gallery-item"> 
                        <img class="gallery-img img-fluid" src="{{ asset('frontend/assets/img/gallery/Bulk_Manufacturing_(11).webp') }}" alt="Bulk Manufacturing"/> 
                     </div>
                 </div>
            </div>
        </div>
        <!-- = -->
        <div class="container mt-5 gallery-wrapper">
            <div class="row text-center mx-auto">
                <div class="sec-title ">
                    <h2 class="mb-0 pb-3">Care </h2>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-4  col-md-6">
                    <div class="gallery-item">
                      <img class="gallery-img img-fluid" src="{{ asset('frontend/assets/img/gallery/Care.webp') }}" alt="care instruction"/> 
                    </div>
                </div>
                <div class="col-lg-4  col-md-6">
                    <div class="gallery-item">
                      <img class="gallery-img img-fluid" src="{{ asset('frontend/assets/img/gallery/Care1.webp') }}" alt="care instruction"/> 
                    </div>
                </div>
                <div class="col-lg-4  col-md-6">
                    <div class="gallery-item">
                      <img class="gallery-img img-fluid" src="{{ asset('frontend/assets/img/gallery/Care2.webp') }}" alt="care instruction"/> 
                    </div>
                </div>
                <div class="col-lg-4  col-md-6">
                    <div class="gallery-item">
                      <img class="gallery-img img-fluid" src="{{ asset('frontend/assets/img/gallery/Care3.webp') }}" alt="care instruction"/> 
                    </div>
                </div>
                <div class="col-lg-4  col-md-6">
                    <div class="gallery-item">
                      <img class="gallery-img img-fluid" src="{{ asset('frontend/assets/img/gallery/Care4.webp') }}" alt="care instruction"/> 
                    </div>
                </div>
                <div class="col-lg-4  col-md-6">
                    <div class="gallery-item">
                      <img class="gallery-img img-fluid" src="{{ asset('frontend/assets/img/gallery/Care5.webp') }}" alt="care instruction"/> 
                    </div>
                </div>
            </div>
        </div>
        <!-- = -->
        <div class="container mt-5 gallery-wrapper">
            <div class="row text-center mx-auto">
                <div class="sec-title ">
                    <h2 class="mb-0 pb-3">Machine </h2>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-3  col-md-6">
                    <div class="gallery-item"> 
                        <img class="gallery-img img-fluid" src="{{ asset('frontend/assets/img/gallery/Machine(1).webp') }}" alt="Machine"/> 
                    </div>
                </div>
                <div class="col-lg-3  col-md-6">
                    <div class="gallery-item"> 
                        <img class="gallery-img img-fluid" src="{{ asset('frontend/assets/img/gallery/Machine(2).webp') }}" alt="Machine"/> 
                    </div>
                </div>
                <div class="col-lg-3  col-md-6">
                    <div class="gallery-item"> 
                        <img class="gallery-img img-fluid" src="{{ asset('frontend/assets/img/gallery/Machine(3).webp') }}" alt="Machine"/> 
                    </div>
                </div>
                <div class="col-lg-3  col-md-6">
                    <div class="gallery-item"> 
                        <img class="gallery-img img-fluid" src="{{ asset('frontend/assets/img/gallery/Machine(4).webp') }}" alt="Machine"/> 
                    </div>
                </div>
                <div class="col-lg-4  col-md-6">
                    <div class="gallery-item"> 
                        <img class="gallery-img img-fluid" src="{{ asset('frontend/assets/img/gallery/Machine(5).webp') }}" alt="Machine"/> 
                    </div>
                </div>
                <div class="col-lg-4  col-md-6">
                    <div class="gallery-item"> 
                        <img class="gallery-img img-fluid" src="{{ asset('frontend/assets/img/gallery/Machine(6).webp') }}" alt="Machine"/> 
                    </div>
                </div>
                <div class="col-lg-4  col-md-6">
                    <div class="gallery-item"> 
                        <img class="gallery-img img-fluid" src="{{ asset('frontend/assets/img/gallery/Machine(7).webp') }}" alt="Machine"/> 
                    </div>
                </div>
              
            </div>
        </div>
       <!-- == -->
       <div class="container mt-5 gallery-wrapper">
            <div class="row text-center mx-auto">
                <div class="sec-title ">
                    <h2 class="mb-0 pb-3">Team </h2>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-4  col-md-6">
                    <div class="gallery-item"> 
                        <img class="gallery-img img-fluid" src="{{ asset('frontend/assets/img/gallery/Team.webp') }}" alt="Team"/> 
                    </div>
                </div>
                <div class="col-lg-4  col-md-6">
                     <div class="gallery-item"> 
                        <img class="gallery-img img-fluid" src="{{ asset('frontend/assets/img/gallery/Team(1).webp') }}" alt="Team"/> 
                    </div>
                   
                </div>
                <div class="col-lg-4  col-md-6">
                    <div class="gallery-item"> 
                        <img class="gallery-img img-fluid" src="{{ asset('frontend/assets/img/gallery/Team(2).webp') }}" alt="Team"/> 
                    </div>
                </div>
                <div class="col-lg-3  col-md-6">
                    <div class="gallery-item"> 
                        <img class="gallery-img img-fluid" src="{{ asset('frontend/assets/img/gallery/Team(3).webp') }}" alt="Team"/> 
                    </div>
                </div>
                <div class="col-lg-3  col-md-6">
                    <div class="gallery-item"> 
                        <img class="gallery-img img-fluid" src="{{ asset('frontend/assets/img/gallery/Team(4).webp') }}" alt="Team"/> 
                    </div>
                </div>
                <div class="col-lg-3  col-md-6">
                    <div class="gallery-item"> 
                        <img class="gallery-img img-fluid" src="{{ asset('frontend/assets/img/gallery/Team(5).webp') }}" alt="Team"/> 
                    </div>
                </div>
                <div class="col-lg-3  col-md-6">
                    <div class="gallery-item"> 
                        <img class="gallery-img img-fluid" src="{{ asset('frontend/assets/img/gallery/Team(6).webp') }}" alt="Team"/> 
                    </div>
                </div>
            </div>
        </div>


</x-frontend.app-layout>
