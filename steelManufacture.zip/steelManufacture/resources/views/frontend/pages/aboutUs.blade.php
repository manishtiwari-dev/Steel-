<x-frontend.app-layout>

    @section('title')
        {{ localize('About Us') }} {{ getSetting('title_separator') }} {{ getSetting('system_title') }}
    @endsection
    <!-- ==============banner================ -->
    <section class="page-banner position-relative"
        style="background: url({{ asset('frontend/assets/img/Industries_hero.webp') }})no-repeat;    min-height: 390px;
      background-repeat: no-repeat;background-position: center center;display: flex;">
        <div class="container justify-content-center d-flex">
            <div class="row align-items-center">
                <h1 class="text-white">About Us</h1>
            </div>
        </div>

    </section>
    <!-- About Us -->
    <section>
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-5 col-md-5">
                    <img src="{{ asset('frontend/assets/img/about-us.webp') }}" alt="about-us" class="img-fluid sticky">
                </div>
                <div class="col-lg-7 col-md-7 ps-lg-5">
                    <div class="sec-title" data-aos="fade-up">
                        <h2>
                            {{ $contentObj->about_us_title ?? '' }} </h2>
                        {!! $contentObj->about_us_html ?? '' !!}
                    </div>
                </div>
            </div>
        </div>
    </section>


    <!-- ============= -->
    <!-- <section class="set-bg" style="background-image: url({{ asset('frontend/assets/img/aboutbg.webp') }});">
        <div class="container text-white" data-aos="fade-up">
            <div class="row">
                <div class="col-lg-3 col-sm-6" data-aos="fade-up" data-aos-delay="200">
                    <div class="milestone">
                        <div class="milestone-icon">
                            <img src="{{ asset('frontend/assets/img/plug.webp') }}" alt="">
                        </div>
                        <div class="milestone-text">
                            <span>Clients</span>
                            <h2>+725</h2>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6" data-aos="fade-up" data-aos-delay="300">
                    <div class="milestone">
                        <div class="milestone-icon">
                            <img src="{{ asset('frontend/assets/img/light.webp') }}" alt="">
                        </div>
                        <div class="milestone-text">
                            <span>Growth</span>
                            <h2>45%</h2>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6" data-aos="fade-up" data-aos-delay="400">
                    <div class="milestone">
                        <div class="milestone-icon">
                            <img src="{{ asset('frontend/assets/img/traffic-cone.webp') }}" alt="">
                        </div>
                        <div class="milestone-text">
                            <span>Projects</span>
                            <h2>59</h2>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6" data-aos="fade-up" data-aos-delay="500">
                    <div class="milestone">
                        <div class="milestone-icon">
                            <img src="{{ asset('frontend/assets/img/worker.webp') }}" alt="">
                        </div>
                        <div class="milestone-text">
                            <span>Emploees</span>
                            <h2>138</h2>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section> -->
    <!-- ======= Contact Us Section ======= -->
    <section id="contact" class="py-lg-0 contact-wrapper theme-bg">
        <div class="container" data-aos="fade-up">
            <div class="row align-items-center">
                <!--Info Column-->
                <div class="info-column col-lg-4 col-sm-12 col-xs-12">
                    <div class="inner-column ">
                        <h2 class="text-white">Contact Us</h2>
                        <ul class="list-style-three mt-3">
                            <li><span class="icon fa "><i
                                        class="fas fa-map-marker-alt"></i></span>{{ getSetting('contact_address') }}
                                {{ getSetting('contact_pincode') }}. <br> {{ getSetting('contact_state') }}
                                {{ getSetting('contact_country') }}
                            </li>
                            <li><span class="icon"><i
                                        class="fas fa-phone-alt"></i></span>{{ getSetting('contact_us_number') }}
                            </li>
                            <li><span class="icon fa fa-envelope"></span>{{ getSetting('contact_email') }}</li>
                        </ul>
                        {{-- <p>{{ getSetting('topbar_location') }}</p> --}}
                    </div>
                </div>
                <!--Form Column-->
                <div class="form-column col-lg-8 col-sm-12 col-xs-12 my-5 p-5 bg-white">
                    <div class="inner-column">

                        <!--Default Form-->
                        <div class="default-form">
                            <div class="sec-title mb-0">
                                <h2>Drop us messege for any query</h2>
                                <p>Got a question or need assistance? Drop us your query, and our team will reach out to you as soon as possible.
</p>
                            </div>
                            <form id="contactForm" class="needs-validation" novalidate>
                                <div class="row clearfix">
                                    <div class="form-group col-md-6 col-sm-6 col-xs-12">
                                        <input type="text" class="form-control" name="name" value=""
                                            placeholder="Your name" required="">
                                        <div class="invalid-feedback">
                                            Please enter your name
                                        </div>
                                        @error('name')
                                            <small class="text-danger">{{ $message }}</small>
                                        @enderror
                                    </div>

                                    <div class="form-group col-md-6 col-sm-6 col-xs-12">
                                        <input type="text" class="form-control" name="company_name" value=""
                                            placeholder="Company Name">


                                    </div>

                                    <div class="form-group col-md-6 col-sm-6 col-xs-12">
                                        <input type="text" class="form-control" name="phone" value=""
                                            placeholder="Phone Number" required="">
                                        <div class="invalid-feedback">
                                            Please enter your phone number
                                        </div>
                                        @error('phone')
                                            <small class="text-danger">{{ $message }}</small>
                                        @enderror
                                    </div>

                                    <div class="form-group col-md-6 col-sm-6 col-xs-12">
                                        <input type="email" class="form-control" name="email" value=""
                                            placeholder="Your Email Address" required="">
                                        <div class="invalid-feedback">
                                            Please enter your email address
                                        </div>
                                        @error('email')
                                            <small class="text-danger">{{ $message }}</small>
                                        @enderror
                                    </div>

                                    <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                        <textarea name="message" class="form-control" placeholder="Specify Your Requirement..."></textarea>
                                    </div>

                                    <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                        <button type="submit" class=" theme-btn btn-style py-2 px-4 btn-black">Submit
                                            now</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <!--End Contact Form-->

                    </div>
                </div>
            </div>
        </div>
    </section><!-- End Contact Us Section -->

</x-frontend.app-layout>
