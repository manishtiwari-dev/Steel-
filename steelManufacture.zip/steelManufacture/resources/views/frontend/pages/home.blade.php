<x-frontend.app-layout>

@section('title')
    {{ localize('Home') }} {{ getSetting('title_separator') }} {{ getSetting('system_title') }}
@endsection

@section('meta')
<meta itemprop="name" content="{{ getSetting('global_meta_title') }}" />
<meta itemprop="image" content="{{ uploadedAsset(getSetting('global_meta_image')) }}" />
<meta property="og:title" content="{{ getSetting('global_meta_title') }}" />
<meta property="og:type" content="website" />
<meta property="og:url" content="{{ route('home') }}" />
<meta property="og:image" content="{{ uploadedAsset(getSetting('global_meta_image')) }}" />
<meta property="og:description" content="{{ getSetting('global_meta_description') }}" />
<meta property="og:site_name" content="{{ env('APP_NAME') }}" /> 
@endsection

<!--Slider-->
@include('frontend.partials.slider')
 
<!--Page Content-->

<main id="main">
    
  {{-- @dd($featureProducts) --}}
    <!-- ======= Product Section ======= -->
    <div id="product">
      @if(!empty($featureProducts))
      @foreach ($featureProducts as $products)

      {{-- @dd($products) --}}
      @if($loop->odd)
      <section class="products position-relative" style="background:url({{asset('frontend/assets/img/bg-image.webp')}});">
        <div class="container shadow-none" data-aos="fade-up">
          <div class="row align-items-center no-gutters">
            <div class="col-lg-4 col-md-4">
              <img src="{{ uploadedAsset($products->thumbnail_image) }}" class="img-fluid" alt="{{ $products->collectLocalization('name') }}">
            </div>
            <div class="col-lg-8 col-md-8">
              <div class="product-content">
                <h3 class="text-dark mb-2">{{$products->name ?? ''}}</h3>
                <p>
                  {!!$products->short_description ?? ''!!}
                 </p>
              </div>
            </div>
          </div>
      </section>
       @endif 
      @endforeach
      @endif

      <section class="products position-relative" >
        <div class="container  shadow-none" data-aos="fade-up" data-aos-delay="200">
          <div class="row align-items-center">
            <div class="col-lg-8 col-md-8">
              <div class="product-content">
                <h3 class="text-dark mb-2"> CUSTOM FABRICATION</h3>
                <p>
                  Lorem ipsum dolor sit amet consectetur adipisicing elit. Repellat unde magnam recusandae eum? Sapiente
                  autem eveniet sunt. Cupiditate repellat nostrum sit odio impedit a magnam et deleniti voluptas, aliquam
                  doloremque illum ipsam amet cumque quis officiis corrupti officia iure aliquid quas in architecto. </p>
              </div>
            </div>
            <div class="col-lg-4 col-md-4">
              <img src="./assets/img/product/img.png" class="img-fluid" alt="product-img">
            </div>
    
          </div>
        </div>

      </section>

      {{-- <section class="products position-relative" style="background:url({{asset('frontend/assets/img/bg-image.webp')}});">
        <div class="container shadow-none" data-aos="fade-up" data-aos-delay="200">
          <div class="row align-items-center">
            <div class="col-lg-4 col-md-4">
              <img src="./assets/img/product/img.png" class="img-fluid" alt="product-img">
            </div>
            <div class="col-lg-8 col-md-8">
              <div class="product-content">
                <h3 class="text-dark mb-2"> CUSTOM FABRICATION</h3>
                <p>
                  Lorem ipsum dolor sit amet consectetur adipisicing elit. Repellat unde magnam recusandae eum? Sapiente
                  autem eveniet sunt. Cupiditate repellat nostrum sit odio impedit a magnam et deleniti voluptas, aliquam
                  doloremque illum ipsam amet cumque quis officiis corrupti officia iure aliquid quas in architecto. </p>
              </div>
            </div>
          </div>
        </div>
      </section> --}}



    </div>
    <!-- End Product Section -->




    <!-- ======= Counts Section ======= -->
    <section class="counts ">
      <div class="container">

        <div class="row">

          <div class="col-lg-3 col-md-6 text-center" data-aos="fade-up">
            <div class="count-box">
              <i class="bi bi-simple-smile" style="color: #20b38e;"></i>
              <span data-purecounter-start="0" data-purecounter-end="232" data-purecounter-duration="1"
                class="purecounter"></span>
              <p>Industries Served</p>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 text-center" data-aos="fade-up" data-aos-delay="200">
            <div class="count-box">
              <i class="bi bi-document-folder" style="color: #c042ff;"></i>
              <span data-purecounter-start="0" data-purecounter-end="521" data-purecounter-duration="1"
                class="purecounter"></span>
              <p>Capability</p>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 text-center" data-aos="fade-up" data-aos-delay="400">
            <div class="count-box">
              <i class="bi bi-live-support" style="color: #46d1ff;"></i>
              <span data-purecounter-start="0" data-purecounter-end="1463" data-purecounter-duration="1"
                class="purecounter"></span>
              <p>Machinery</p>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 text-center" data-aos="fade-up" data-aos-delay="600">
            <div class="count-box">
              <i class="bi bi-users-alt-5" style="color: #ffb459;"></i>
              <span data-purecounter-start="0" data-purecounter-end="15" data-purecounter-duration="1"
                class="purecounter"></span>
              <p>Production Capacity</p>
            </div>
          </div>
          <div class="col-lg-3 col-md-6 text-center" data-aos="fade-up" data-aos-delay="600">
            <div class="count-box">
              <i class="bi bi-users-alt-5" style="color: #ffb459;"></i>
              <span data-purecounter-start="0" data-purecounter-end="15" data-purecounter-duration="1"
                class="purecounter"></span>
              <p>Achivement</p>
            </div>
          </div>

        </div>

      </div>
    </section><!-- End Counts Section -->

    <!-- ========================== -->
    <section class="theme-bg call-to-action-section" style="background:url({{asset('frontend/assets/img/bg-img.jpg')}})no-repeat;background-position: center;    position: relative;background-position: center center;background-repeat: no-repeat;background-size: cover;">
        <div class="container position-relative">
            <div class="row align-items-center clearfix">
                <div class="pull-left col-lg-8 col-md-8">
                  <div>
                    <h2 class="text-black fs-50">Looking for a best <span>Manufacturing</span> Company</h2>
                  </div>
                </div>

                <div class="pull-right col-lg-4 col-md-4 text-md-end">
                    <a href="#contact" class="btn-black btn-style border-0 text-white fs-18">Start Your Project Now </a>
                </div>
            </div>
            
        </div>
    </section>
    <!-- ========================== -->
    <section class="why-section py-5 ">
      <div class="container-fluid">
        <div class="row mx-auto text-center">
          <div class="wrap">
            <button class="why-btn p-0"><div class="d-flex  align-items-center">  
              <span>
                <i class="fas fa-chevron-right" aria-hidden="true"></i>
              </span>
              <div class="why-choose-title px-2">
                Why Choose Us? 
              </div>					
            
            </div>
          </button>
            <div class="content">
              <h3 class="text-black mb-2">Lorem ipsum dolor sit amet.</h3>
              <p>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Debitis quae reprehenderit minus ipsam recusandae, nisi fuga rem a laudantium reiciendis et vel illum odit soluta, id modi. Harum, debitis distinctio!
              </p>
            </div>
            </div>
        </div>
      </div>
    </section>
      
    <!--============ Why Us End ==============-->

    <!-- ======= services Details Section ======= -->
    <section id="service" class="services-details pt-0">
      <div class="container" data-aos="fade-up">

        <div class="row gy-4">
          @php
          $galleryImages = explode(',', $contentObj->about_us_image);
          @endphp
          <div class="col-lg-7">
            <div id="carouselExampleSlidesOnly" class="carousel slide" data-bs-ride="carousel">
              <div class="carousel-inner">
                @if(!empty($galleryImages))
                @foreach ($galleryImages as $galleryImage)
                <div class="carousel-item @if ($loop->first)  active @endif">
                  <img src="{{ uploadedAsset($galleryImage) }}" alt="{{ $contentObj->about_us_title ?? ''}}"
                  class="d-block w-100">
                </div>
                @endforeach
                @endif
              </div>
            </div>
          </div>

          <div class="col-lg-5 ps-lg-5">
            <div class="services-description">
              <div class="sec-title">
                <h2>{{$contentObj->about_us_title ?? ''}} </h2>
              </div>
              {!! $contentObj->about_us_html ?? '' !!}
            </div>
          </div>

        </div>

      </div>
    </section>
    <!-- End services Details Section -->

    <!-- ======= Contact Us Section ======= -->
    <section id="contact" class="py-0 contact-wrapper theme-bg">
      <div class="container" data-aos="fade-up">
        <div class="row align-items-center">
          <!--Info Column-->
          <div class="info-column col-md-4 col-sm-12 col-xs-12">
            <div class="inner-column ">
              <h2 class="text-white">Contact Us</h2>
              <ul class="list-style-three mt-3">
                <li><span class="icon fa "><i class="fas fa-map-marker-alt"></i></span>2624 Lorem, ipsum. <br> Lorem, CO
                  80014</li>
                <li><span class="icon"><i class="fas fa-phone-alt"></i></span>1800-456-7890</li>
                <li><span class="icon fa fa-envelope"></span>contact.xyz@gmail.com</li>
              </ul>
            </div>
          </div>
          <!--Form Column-->
          <div class="form-column col-md-8 col-sm-12 col-xs-12 my-5 p-5 bg-white">
            <div class="inner-column">

              <!--Default Form-->
              <div class="default-form">
                <div class="sec-title mb-0">
                  <h2>Drop us messege for any query</h2>
                  <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Officiis qui delectus minus distinctio
                    quisquam omnis?</p>
                </div>
                <form  id="contactForm" class="needs-validation" novalidate>
                  <div class="row clearfix">
                    <div class="form-group col-md-6 col-sm-6 col-xs-12">
                      <input type="text" class="form-control" name="name" value="" placeholder="Your name" required="">
                      <div class="invalid-feedback">
                       Please enter your name
                      </div>
                      @error('name')
                      <small class="text-danger">{{ $message }}</small>
                      @enderror
                    </div>

                    <div class="form-group col-md-6 col-sm-6 col-xs-12">
                      <input type="text" class="form-control"  name="company_name" value="" placeholder="Company Name" >
                      {{-- @error('subject')
                      <small class="text-danger">{{ $message }}</small>
                      @enderror --}}

                    </div>

                    <div class="form-group col-md-6 col-sm-6 col-xs-12">
                      <input type="text" class="form-control"  name="phone" value="" placeholder="Phone Number" required="">
                      <div class="invalid-feedback">
                        Please enter your phone number
                       </div>
                      @error('phone')
                      <small class="text-danger">{{ $message }}</small>
                      @enderror
                    </div>

                    <div class="form-group col-md-6 col-sm-6 col-xs-12">
                      <input type="email"  class="form-control" name="email" value="" placeholder="Your Email Address" required="">
                      <div class="invalid-feedback">
                        Please enter your email address
                       </div>
                      @error('email')
                      <small class="text-danger">{{ $message }}</small>
                      @enderror
                    </div>

                    <div class="form-group col-md-12 col-sm-12 col-xs-12">
                      <textarea name="message"  class="form-control" placeholder="Specify Your Requirement..."></textarea>
                    </div>

                    <div class="form-group col-md-12 col-sm-12 col-xs-12">
                      <button type="submit" class=" theme-btn btn-style py-2 px-4 btn-black">Submit now</button>
                    </div>
                  </div>
                </form>
              </div>
              <!--End Contact Form-->

            </div>
          </div>
        </div>
      </div>
    </section><!-- End Contact Us Section -->

  </main><!-- End #main -->



</x-frontend.app-layout>