<x-frontend.app-layout>

    <h1>Blog Lists</h1>
    
</x-frontend.app-layout>