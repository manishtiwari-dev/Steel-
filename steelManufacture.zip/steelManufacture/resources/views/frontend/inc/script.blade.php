  <!-- Vendor JS Files -->
  <script src="https://code.jquery.com/jquery-3.3.1.js"></script>
  <script src="{{asset('frontend/assets/vendor/purecounter/purecounter_vanilla.js')}}"></script>
  <script src="{{asset('frontend/assets/vendor/aos/aos.js')}}"></script>
  <script src="{{asset('frontend/assets/vendor/bootstrap/js/bootstrap.bundle.min.js')}}"></script>
  <script src="{{asset('frontend/assets/vendor/glightbox/js/glightbox.min.js')}}"></script>


  <!-- Template Main JS File -->
  <script src="{{asset('frontend/assets/js/main.js')}}"></script>

  <script type="text/javascript">
    $(window).on('scroll', function () {
      if ($(window).scrollTop()) {
        $('header').addClass('black');
      }
      else {
        $('header').removeClass('black');
      }
    })
    /*menu button onclick function*/
    $(document).ready(function () {
      $('.menu h4').click(function () {
        $("nav ul").toggleClass("active")
      })
    })
  </script>

  <script>
    $(".why-btn").click (function(){
  // Close all open windows
  $(".content").stop().slideUp(300); 
  // Toggle this window open/close
  $(this).next(".content").stop().slideToggle(300);
 
});

  </script> 
  

<script>
    // ajax toast 
    function notifyMe(level, message) {
        if (level == 'danger') {
            level = 'error';
        }
        toastr.options = {
            "timeOut": "50000",
            "closeButton": true,
            "positionClass": "toast-top-center",
        };
        toastr[level](message);
    }
    @foreach (session('flash_notification', collect())->toArray() as $message)

        notifyMe("{{ $message['level'] }}", "{{ $message['message'] }}");
    @endforeach


    @if (!empty($errors->all()))
        @foreach ($errors->all() as $error)
            notifyMe("error", '{{ $error }}')
        @endforeach
    @endif
</script>
<script>
$(document).ready(function() {

  $('#contactForm').on('submit', function(event){
  event.preventDefault();
  
      $.ajaxSetup({
          headers: {
              "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr(
                  "content"
              ),
          },
      });
      var enqData = document.getElementById("contactForm");
      var formData = new FormData(enqData);

      $.ajax({
          type: "POST",
          url:"{{ route('contactUs.store') }}",
          data: formData,
          cache: false,
          contentType: false,
          processData: false,
          success: function(response) {
              if (response.status == 400) {

                  // $.each(response.error, function (key, err_val) {
                  //     $('.' + key + '_error').text(err_val);
                  // });

              } else {

                  $('#contacForm').trigger("reset");
                 // $('#quote').modal('hide');
                  notifyMe('success', response.message);
              }
          },
          error: function(data) {
              console.log(data);
          },
      });
  });
});
</script>
