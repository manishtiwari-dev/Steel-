<!-- ======= Header ======= -->
@php
    // $current_url =  url()->current();
    // $domain = Request::root();
    // $indexurl = str_replace($domain,'', $current_url);

    $root_index = Request::segment(1);
    //dd($root_index);
@endphp


<!-- ======= Header ======= -->
<header id="header" class="d-lg-block d-none">
    <div class="align-items-center">

        <div class="logo me-auto">

            <a href="{{ url('/') }}"><img src="{{ uploadedAsset(getSetting('navbar_logo')) }}" alt=""
                    class="img-fluid"></a>
        </div>
        <div class="utility-nav d-flex gap-3 pt-2">
            <div>
                <a href="mailto:{{ getSetting('contact_email') }}" class="">Email: {{ getSetting('contact_email') }}</a>

            </div>
            <div>

                <a href="tel:{{ getSetting('contact_us_number') }}" class="">Call: {{ getSetting('contact_us_number') }}</a>
            </div>

        </div>
        <nav id="navbar" class="navbar">
            <ul>


                <li><a class="nav-link {{ in_array($root_index, ['company-profile']) ? 'active ' : '' }} "
                        href="{{ route('home.companyProfile') }}">Company Profile</a>
                </li>
                <li><a class="nav-link {{ in_array($root_index, ['about-us']) ? 'active ' : '' }} "
                        href="{{ route('home.aboutUs') }}">About Us</a></li>
                <li><a class="nav-link {{ in_array($root_index, ['gallery']) ? 'active ' : '' }}" href="{{ route('home.gallery') }}">Gallery</a></li>
                <li><a class="nav-link" href="{{ url('/') }}/#contact">Contact Us</a></li>



            </ul>
            <i class="bi bi-list mobile-nav-toggle"></i>
        </nav><!-- .navbar -->
        <div class="estimate-btn"> <a href="mailto:{{ getSetting('contact_email') }}" class="text-white">Request An Estimate</a></div>
    </div>
</header><!-- End Header -->

<div class="d-lg-none d-block">

    <nav class="navbar-wrapper ">
        <div class="text-center">
            <a href="index.html"><img src="{{ uploadedAsset(getSetting('navbar_logo')) }}" alt=""
                    class="img-fluid" style="width:150px"></a>
            <div class="utility-nav d-flex gap-3 py-3">
                <div>
                    <a href="mailto:{{ getSetting('contact_email') }}" class="text-white">Email: {{ getSetting('contact_email') }}</a>

                </div>
                <div>

                    <a href="tel:{{ getSetting('contact_us_number') }}" class="text-white">Call:{{ getSetting('contact_us_number') }}</a>
                </div>

            </div>
        </div>
        <div class="d-flex ps-3 navbar-container-wrapper">

            <div class="navbar-container container">
                <!-- <input type="checkbox" name="" id=""> -->
                <div class="hamburger-lines show" onclick="funcShow();">
                    <span class="line line1"></span>
                    <span class="line line2"></span>
                    <span class="line line3"></span>
                </div>
                <div>

                </div>
                <ul class="menu-items hide-conatiner">
                    <div class="close-btn hide" onclick="funcShow();">
                        <span class="close">&times;</span>
                    </div>

                    <li><a href="{{ route('home.companyProfile') }}">Company Profile</a></li>
                    <li><a href="{{ route('home.aboutUs') }}">About Us</a></li>
                    <li><a href="{{ route('home.gallery') }}">Gallery</a></li>
                    <li><a href="{{ url('/') }}/#contact">Contact Us</a></li>
                </ul>

            </div>
            <div class="estimate-btn"> <a href="mailto:{{ getSetting('contact_email') }}" class="text-white">Request An Estimate</a></div>
        </div>

    </nav>
</div>
