<!-- Google Fonts -->
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,600,600i,700,700i,900"
rel="stylesheet">

<!-- Vendor CSS Files -->
<link href="{{asset('frontend/assets/vendor/animate.css/animate.min.css')}}" rel="stylesheet">
<link href="{{asset('frontend/assets/vendor/aos/aos.css')}}" rel="stylesheet">
<link href="{{asset('frontend/assets/vendor/bootstrap/css/bootstrap.min.css')}}" rel="stylesheet">
<link href="{{asset('frontend/assets/vendor/bootstrap-icons/bootstrap-icons.css')}}" rel="stylesheet">
<script src="https://kit.fontawesome.com/847e2a6f25.js" crossorigin="anonymous"></script>

<!-- Template Main CSS File -->
<link href="{{asset('frontend/assets/css/style.css')}}" rel="stylesheet">

<link rel="stylesheet" href="{{ asset('frontend/common/css/toastr.css')}}">
<link rel="stylesheet" href="{{ asset('frontend/common/css/custom.css')}}">