{{-- <footer id="site-footer" class="site-footer footer-12">
  <div class="container-fluid">
      <div class="space-20"></div>
      <div class="row">
          <div class="col-md-4 mb-4 mb-md-0 align-self-center">
              <p class="copyright-text-12 mb-0">
                {!! getSetting('copyright_text') !!}
              </p>
          </div>
          @php
          $quick_links = getSetting('quick_links') != null ? json_decode(getSetting('quick_links')) : [];
          $pages = \App\Models\Page::whereIn('id', $quick_links)->get();
          @endphp
          <div class="col-md-6 text-md-right align-self-center">
              <ul class="ft-menu-i12">
                @if (!empty($pages))
                  @foreach ($pages as $item)    
                    <li><a href="{{ route('home.pages.show', $item->slug) }}">{{ $item->collectLocalization('title') }}</a></li>
                  @endforeach
                @endif  
              </ul>
          </div>
          <div class="col-lg-2">
          <span class="fs-14">
            Made With <svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="18px"  height="18px"  x="0px" y="0px" viewBox="0 0 122.88 107.41" style="enable-background:new 0 0 122.88 107.41" xml:space="preserve"><style type="text/css">.st0{fill-rule:evenodd;clip-rule:evenodd;fill:#ff0000ab}</style><g><path class="st0" d="M60.83,17.19C68.84,8.84,74.45,1.62,86.79,0.21c23.17-2.66,44.48,21.06,32.78,44.41 c-3.33,6.65-10.11,14.56-17.61,22.32c-8.23,8.52-17.34,16.87-23.72,23.2l-17.4,17.26L46.46,93.56C29.16,76.9,0.95,55.93,0.02,29.95 C-0.63,11.75,13.73,0.09,30.25,0.3C45.01,0.5,51.22,7.84,60.83,17.19L60.83,17.19L60.83,17.19z"/></g></svg> <a href="https://invoidea.com/"  class="text-dark" target="_blank">Invoidea</a>
        </span>
          </div>
      </div>
      <div class="space-20"></div>
  </div>
</footer><!-- #site-footer --> --}}



<!-- ======= Footer ======= -->
<footer class="main-footer pt-5" style="background-image:url({{ asset('frontend/assets/img/footer-bg.jpg') }})">
    <div class="container">

        <div class="row pb-4">

            <!--big column-->
            <div class="footer-column col-lg-5 col-md-6 col-sm-12 mb-lg-0 mb-3">
                <div class="footer-widget logo-widget">
                    <div class="logo float-none">
                        <a href=""><img src="{{ uploadedAsset(getSetting('footer_logo')) }}" alt=""> </a>
                    </div>
                    <div class="text">LRG Steel Concept Pvt Ltd is a premier sheet metal concepting company with a rich legacy of over two decades. We have been at the forefront of the industry, utilizing the latest technology and cutting-edge machinery from renowned manufacturers such as Amada (Japan) and Trumpf (Germany). Our commitment to excellence and innovation has positioned us as a trusted partner for a wide range of industries, delivering high-quality solutions that meet the diverse needs of our clients.</div>
                </div>
            </div>
            <!--Footer Column-->
            <div class="footer-column  col-lg-3 col-md-6 col-sm-12 mb-lg-0 mb-3 ps-lg-5">
                <div class="footer-widget links-widget">
                    @php
                        $quick_links = getSetting('quick_links') != null ? json_decode(getSetting('quick_links')) : [];
                        $pages = \App\Models\Page::whereIn('id', $quick_links)->get();
                    @endphp
                    <div class="footer-title">
                        <h2>Quick Links</h2>
                    </div>
                    <ul class="footer-lists">
                        {{-- @if (!empty($pages))
                  @foreach ($pages as $item)    
                    <li><a href="{{ route('home.pages.show', $item->slug) }}">{{ $item->collectLocalization('title') }}</a></li>
                  @endforeach
                @endif  --}}
                        <li><a href="{{ route('home.companyProfile') }}">Company Profile</a></li>
                        <li><a href="{{ route('home.aboutUs') }}">About Us</a></li>
                        <li><a href="{{ route('home.gallery') }}">Gallery</a></li>
                        <!-- <li><a href="#contact">Contact Us</a></li> -->
                    </ul>
                    <ul class="social-icon mt-5">
                            <li class="follow">Follow us :</li>
                            <!-- <li><a href="{{ getSetting('facebook_link') }}"><span class="fa fa-facebook"></span></a>
                            </li> -->
                            <li><a href="{{ getSetting('instagram_link') }}"><span class="fa fa-instagram"></span></a></li>
                        </ul>
                </div>
            </div>
            <!--Footer Column-->
            <div class="footer-column col-lg-4 col-md-6 col-sm-12">
                <div class="footer-widget subscribe-widget">
                <div class="footer-title" bis_skin_checked="1">
                        <h2 class="mb-4">Contact Us</h2>
                        <div class="text mb-2" bis_skin_checked="1">
                            <b style="font-weight:500">Address :</b>
                            {{ getSetting('contact_address') }}
                                    {{ getSetting('contact_pincode') }}. <br> {{ getSetting('contact_state') }}
                                    {{ getSetting('contact_country') }}
                        </div>
                        <div class="text" bis_skin_checked="1">
                            <b style="font-weight:500">Phone No :</b>{{ getSetting('contact_us_number') }}
                        </div>
                    </div>
                    <div class="footer-title mb-3">
                        <h2>Subscribe Us</h2>
                    </div>
                    <div class="widget-content">
                        <div class="text">Sign up today for tips and latest news and exclusive special offers.</div>
                        <div class="subscribe-form mt-3">
                            <form id="newslatterform" class="needs-validation" novalidate method="post">
                                @csrf
                                <div class="form-group">
                                    <input type="email" class="form-control" name="email" placeholder="Email Address"
                                        required="">
                                    <div class="invalid-feedback">
                                        Please enter email.
                                    </div>
                                    <button type="button" id="mail_subscribe" class="theme-btn"><span class="fa fa-send"></span></button>
                                </div>
                            </form>
                        </div>
                       
                    </div>
                </div>
            </div>

        </div>

    </div>
    <div class="footer-bottom">
        <div class="container">
           <div class="row">
             <div class="col-lg-7  text-lg-end col-6 text-center">
                <div class="copyright">{!! getSetting('copyright_text') !!}</div>
             </div>
                <div class="col-lg-5 text-lg-end col-6 text-center">
                    <span class="fs-14">
                            Made With <svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="18px" height="18px" x="0px" y="0px" viewBox="0 0 122.88 107.41" style="enable-background:new 0 0 122.88 107.41" xml:space="preserve"><style type="text/css">.st0{fill-rule:evenodd;clip-rule:evenodd;fill:#ff0000ab}</style><g><path class="st0" d="M60.83,17.19C68.84,8.84,74.45,1.62,86.79,0.21c23.17-2.66,44.48,21.06,32.78,44.41 c-3.33,6.65-10.11,14.56-17.61,22.32c-8.23,8.52-17.34,16.87-23.72,23.2l-17.4,17.26L46.46,93.56C29.16,76.9,0.95,55.93,0.02,29.95 C-0.63,11.75,13.73,0.09,30.25,0.3C45.01,0.5,51.22,7.84,60.83,17.19L60.83,17.19L60.83,17.19z"></path></g></svg> <a href="https://invoidea.com/" class="text-dark" target="_blank">Invoidea</a>
                    </span>
                </div>
           </div>
        </div>
    </div>
</footer>


<!--Contact Modal -->
<div class="modal fade" id="ContactModal" tabindex="-1" aria-labelledby="ContactModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="ContactModalLabel">Request An Estimate</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">

                <div class="form-column">
                    <div class="inner-column">
                        <!--Default Form-->
                        <div class="default-form">
                            <div class="sec-title mb-0">
                                <h2>Drop us messege for any query</h2>
                                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Officiis qui delectus minus
                                    distinctio
                                    quisquam omnis?</p>
                            </div>
                            <form class="needs-validation" novalidate id="contactModalForm">
                                <div class="row clearfix">
                                    <div class="form-group col-md-6 col-sm-6 col-xs-12">
                                        <input type="text" class="form-control" name="name" value=""
                                            placeholder="Your name" required="">
                                        <div class="invalid-feedback">
                                            Please enter your name
                                        </div>
                                        @error('name')
                                            <small class="text-danger">{{ $message }}</small>
                                        @enderror
                                    </div>

                                    <div class="form-group col-md-6 col-sm-6 col-xs-12">
                                        <input type="text" class="form-control" name="company_name" value=""
                                            placeholder="Company Name">
                                    </div>

                                    <div class="form-group col-md-6 col-sm-6 col-xs-12">
                                        <input type="text" class="form-control" name="phone" value=""
                                            placeholder="Phone Number" required="">
                                        <div class="invalid-feedback">
                                            Please enter your phone number
                                        </div>
                                        @error('phone')
                                            <small class="text-danger">{{ $message }}</small>
                                        @enderror
                                    </div>

                                    <div class="form-group col-md-6 col-sm-6 col-xs-12">
                                        <input type="email" class="form-control" name="email" value=""
                                            placeholder="Your Email Address" required="">
                                        <div class="invalid-feedback">
                                            Please enter your email address
                                        </div>
                                        @error('email')
                                            <small class="text-danger">{{ $message }}</small>
                                        @enderror
                                    </div>

                                    <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                        <textarea name="message" placeholder="Specify Your Requirement..."></textarea>
                                    </div>

                                    <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                        <button type="submit" class=" theme-btn btn-style py-2 px-4 btn-black">Submit
                                            now</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <!--End Contact Form-->

                    </div>
                </div>

            </div>

        </div>
    </div>
</div>

<!-- wpp-btn-mobile -->
<div class="phone-call cbh-phone cbh-green cbh-show  cbh-static" id="clbh_phone_div"><a id="WhatsApp-button"
        href="https://wa.me/" target="_blank" class="" title="WhatsApp">
        <div class="cbh-ph-circle"></div>
        <div class="cbh-ph-circle-fill"></div>
        <div class="cbh-ph-img-circle1"></div>
    </a></div>
<!-- wpp-btn-mobile -->

@push('scripts')
    <script>
        $(document).ready(function() {
            $(document).on('click', '#mail_subscribe', function(e) {
                e.preventDefault();
                
                let $subsBtn = $(this);
                let debounceTimer;
                
                if (!$subsBtn.hasClass('disabled')) {

                $subsBtn.addClass('disabled');

                clearTimeout(debounceTimer);
                debounceTimer = setTimeout(function() {
                    
                $('#newslatterform').addClass('was-validated');
                if ($('#newslatterform')[0].checkValidity() === false) {
                    e.stopPropagation();
                } else {
                
                    let enquiryform = document.getElementById('newslatterform');
                    var data = new FormData(enquiryform);

                    $.ajaxSetup({
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        }
                    });
                    $.ajax({
                        type: "POST",
                        url: "{{ route('subscribe.store') }}",
                        data: data,
                        dataType: "json",
                        contentType: false,
                        cache: false,
                        processData: false,

                        beforeSend: function() {
                            $("#mail_subscribe").addClass('disabled');
                        },

                        success: function(response) {
                            if (response.status == 400) {
                                notifyMe("error", response.message)
                           
                            } else {
                                $('#newslatterform').removeClass('was-validated');
                                notifyMe("success", response.message)
                                $("#newslatterform").trigger("reset")
                            }
                        },
                        complete: function(response) {
                            $('#mail_subscribe').removeClass('disabled');
                        },
                    });
                }
                
               }, 500);

               }
            });
        });
    </script>
  @endpush