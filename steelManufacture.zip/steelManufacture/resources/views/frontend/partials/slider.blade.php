<!-- ==slider== -->

 <!-- ======= Hero Section ======= -->
 <section id="hero">
    <div class="hero-container">
      <div id="heroCarousel" class="carousel slide carousel-fade" data-bs-ride="carousel" data-bs-interval="5000">

        <ol class="carousel-indicators" id="hero-carousel-indicators"></ol>

        <div class="carousel-inner" role="listbox">

          <!-- Slide 1 -->
          @if(!empty($sliders))
          @foreach ($sliders as $slider)
          <div class="carousel-item  @if ($loop->first)  active @endif" style="background-image: url('{{ uploadedAsset($slider->desktop_image) }}');">
            <div class="carousel-container">
              <div class="carousel-content container">
                <h2 class="animate__animated animate__fadeInDown">{{$slider->title ?? ''}}</h2>
                <p class="animate__animated animate__fadeInUp">{{$slider->description ?? ''}} </p>
                <a href="{{$slider->link ?? ''}}" class="btn-get-started animate__animated animate__fadeInUp scrollto">{{$slider->button_name ?? ''}}</a>
              </div>
            </div>
          </div>
          @endforeach
          @endif
        </div>

        <a class="carousel-control-prev" href="#heroCarousel" role="button" data-bs-slide="prev">
          <span class="carousel-control-prev-icon bi bi-chevron-left" aria-hidden="true"></span>
        </a>
        <a class="carousel-control-next" href="#heroCarousel" role="button" data-bs-slide="next">
          <span class="carousel-control-next-icon bi bi-chevron-right" aria-hidden="true"></span>
        </a>

      </div>
    </div>
  </section><!-- End Hero -->