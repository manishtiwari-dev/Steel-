<?php

use App\Http\Controllers\Frontend\PageController;
use App\Http\Controllers\Frontend\CategoryController;
use App\Http\Controllers\Frontend\BrandController;
use App\Http\Controllers\Frontend\CareerController;
use App\Http\Controllers\ProfileController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\MediaManagerController;
use App\Http\Controllers\Frontend\HomeController;
use App\Http\Controllers\Frontend\ProductController;
use App\Http\Controllers\Frontend\CartsController;
use App\Http\Controllers\Frontend\CheckoutController;
use App\Http\Controllers\Frontend\ContactUsController;
use App\Http\Controllers\Frontend\AboutUsController;
use App\Http\Controllers\Frontend\CompanyProfileController;
use App\Http\Controllers\Frontend\SubscribersController;

// for clear-cache
Route::get('/cc', function () {

    Artisan::call('cache:clear');
    Artisan::call('config:clear');
    Artisan::call('config:cache');
    Artisan::call('view:clear');
    Artisan::call('route:clear');
    Artisan::call('optimize:clear');

    flash(localize('Cach-Cleared'))->success();
    return back();
})->name('clear-cache');



Route::get('/', [HomeController::class, 'index'])->name('home');



Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});


# Subscribed Users
Route::post('/subscribers', [SubscribersController::class, 'store'])->name('subscribe.store');


# products
Route::get('/products', [ProductController::class, 'index'])->name('products.index');
Route::get('/products/{slug}', [ProductController::class, 'show'])->name('products.show');
Route::post('/products/get-variation-info', [ProductController::class, 'getVariationInfo'])->name('products.getVariationInfo');
Route::post('/products/show-product-info', [ProductController::class, 'showInfo'])->name('products.showInfo');

Route::post('/products/enquiry-store', [ProductController::class, 'enquiryProductStore'])->name('products.enquiryStore');

Route::get('/download/attachment/{id}', [ProductController::class, 'downloadAttachment'])->name('downloadAttachment');

#category
//Route::get('/categories', [HomeController::class, 'allCategories'])->name('home.categories');
//Route::get('/category/{slug}', [CategoryController::class, 'show'])->name('category.show');
//Route::get('/brand/{slug}', [ProductController::class, 'index'])->name('brand.show');


# page
Route::get('/contact-us', [HomeController::class, 'contactUs'])->name('home.contactUs');
Route::get('/page/{slug}', [PageController::class, 'index'])->name('home.pages.show');


Route::post('/contact-us', [ContactUsController::class, 'store'])->name('contactUs.store');

# about
Route::get('/about-us', [AboutUsController::class, 'index'])->name('home.aboutUs');

# companyProfile
Route::get('/company-profile', [CompanyProfileController::class, 'index'])->name('home.companyProfile');

# blogs
// Route::get('/blog', [HomeController::class, 'allBlogs'])->name('home.blogs');
Route::get('/blog/{slug}', [HomeController::class, 'showBlog'])->name('home.blogs.show');

Route::get('/gallery', [HomeController::class, 'gallery'])->name('home.gallery');




# media files routes
Route::group(['prefix' => '', 'middleware' => ['auth']], function () {
    Route::get('/media-manager/get-files', [MediaManagerController::class, 'index'])->name('uppy.index');
    Route::get('/media-manager/get-selected-files', [MediaManagerController::class, 'selectedFiles'])->name('uppy.selectedFiles');
    Route::post('/media-manager/add-files', [MediaManagerController::class, 'store'])->name('uppy.store');
    Route::get('/media-manager/delete-files/{id}', [MediaManagerController::class, 'delete'])->name('uppy.delete');
});




require __DIR__ . '/admin.php';
require __DIR__ . '/auth.php';
