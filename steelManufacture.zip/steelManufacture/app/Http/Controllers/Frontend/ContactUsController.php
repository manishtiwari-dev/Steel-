<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use App\Models\ContactUsMessage;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class ContactUsController extends Controller
{
    # store contact us form data
    public function store(Request $request)
    {


        $validator = Validator::make(
            $request->all(),
            [
                'name' => 'required',
                'email' => 'required|email|unique:sso_contact_us,email',
            ],
            [
                'name.required' => 'Please enter name.',
                'email.required' => 'Please enter email.',
                'email.email' => 'Please enter valid email.',
            ]
        );



        if ($validator->fails()) {
            return response()->json([
                'status' => 400,
                'error' => $validator->messages(),
            ]);
        } else {


            $msg = new ContactUsMessage;
            $msg->name          = $request->name;
            $msg->email         = $request->email;
            $msg->phone         = $request->phone;
            $msg->message       = $request->message;
            $msg->company_name  = $request->company_name;
            $msg->save();

            return response()->json(['message' => 'Thank you! Your message has been successfully sent.', 'status' => 200]);
        }
    }
}
