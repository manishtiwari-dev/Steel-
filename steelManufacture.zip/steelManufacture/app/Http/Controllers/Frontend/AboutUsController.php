<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Page;

class AboutUsController extends Controller
{
    # get states based on country
    public function index(Request $request)
    {
        $sliders = $contents = [];

        if (getSetting('hero_sliders') != null) {
            $sliders = json_decode(getSetting('hero_sliders'));
        }

        if (getSetting('home_page_contents') != null) {
            $contents = json_decode(getSetting('home_page_contents'));
        }

        $contentObj = '';
        if (!empty($contents) && sizeof($contents) > 0)
            $contentObj = $contents[0];

        return getView('pages.aboutUs', ['contentObj' => $contentObj]);
    }
}
