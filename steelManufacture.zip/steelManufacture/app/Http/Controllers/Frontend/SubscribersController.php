<?php

namespace App\Http\Controllers\Frontend;

use Illuminate\Http\Request;
use App\Models\SubscribedUser;
use App\Http\Controllers\Controller;

class SubscribersController extends Controller
{
    # store new subscribers
    public function store(Request $request)
    {   
        $subscriber = SubscribedUser::where('email', $request->email)->first();
        if($subscriber == null){
            $subscriber = new SubscribedUser;
            $subscriber->email = $request->email;
            $subscriber->save();
            return response()->json(['message' => 'You have subscribed successfully.', 'status' => 200]);
        }
        else{
            
            return response()->json(['message' => 'You are  already a subscriber', 'status' => 400]);
        }
        return back();
    }
}
