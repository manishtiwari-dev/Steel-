<?php

namespace App\Http\Controllers\Backend\Appearance;

use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\Page;
use Illuminate\Http\Request;
use App\Models\SystemSetting;
use Artisan;

class ContactUsController extends Controller
{
    # construct
    public function __construct()
    {
        $this->middleware(['permission:homepage'])->only(['hero', 'edit', 'delete']);
    }

    # website header configuration
    public function contact()
    {

        return view('backend.pages.appearance.homepage.contactUs');
    }

    # update settings
    public function update(Request $request)
    {
        foreach ($request->types as $key => $type) {


            # web maintenance mode
            if (
                $type == 'enable_maintenance_mode'
            ) {
                # maintenance
                if (env('DEMO_MODE') != 'On') {
                    if ($request[$type] == "1") {
                        Artisan::call('down');
                    } else {
                        Artisan::call('up');
                    }
                }
            }

            # timezone
            if (
                $type == 'timezone'
            ) {
                writeToEnvFile('APP_TIMEZONE', $request[$type]);
            } else if ($type == "GOOGLE_CLIENT_ID" || $type == "GOOGLE_CLIENT_SECRET" || $type == "FACEBOOK_APP_ID" || $type == "FACEBOOK_APP_SECRET" || $type == "RECAPTCHA_SITE_KEY" || $type == "RECAPTCHA_SECRET_KEY") {
                writeToEnvFile($type, $request[$type]);
            } else {
                $value = $request[$type];

                if ($type == 'system_title') {
                    writeToEnvFile('APP_NAME', $value);
                }

                $settings = SystemSetting::where('entity', $type)->first();
                if ($settings != null) {
                    if (gettype($value) == 'array') {
                        $settings->value = json_encode($value);
                    } else {
                        $settings->value = $value;
                    }
                } else {
                    $settings = new SystemSetting;
                    $settings->entity = $type;
                    if (gettype($value) == 'array') {
                        $settings->value = json_encode($value);
                    } else {
                        $settings->value = $value;
                    }
                }
                $settings->save();
            }
        }

        cacheClear();
        flash(localize("Contact Us updated successfully"))->success();
        return back();
    }
}
